<?php
/**
 * Woocommerce Custom Tab HTML Functions
 *
 * @version 1.0.0
 * @package WC_CustomTabs\classes
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 *
 * @class WC_Custom_Tab_Generat_HTML
 */

if ( ! class_exists( 'WC_Custom_Tab_Generat_HTML' ) ) {
    class WC_Custom_Tab_Generat_HTML {

        /**
         * The single instance of the class.
         *
         * @var class object
         * @since 1.0.0
         */
        protected static $instance = null;

        /**
         * Main WC_Custom_Tab_Generat_HTML Instance.
         *
         * Ensures only one instance of WpContentLocker is loaded or can be loaded.
         *
         * @since 1.0.0
         * @return WC_Custom_Tab_Generat_HTML - Main instance.
         */

        public static function instance() {
            if ( is_null( self::$instance ) ) {
                self::$instance = new self();
            }
            return self::$instance;
        }
        
        /**
         * WC_Custom_Tab_Generat_HTML Constructor.
         *
         * @since 1.0.0
         * @return void
         */
        public function __construct() {
            // empty...
        }

    	/**
    	* Creates all of the HTML required for tabs on the product edit screen
    	*
    	* @since 1.0.0
    	*/
    	public function wct_generate_html() {    	
        	global $post;

            // Pull the custom tab data out of the database
            $tab_data = maybe_unserialize( get_post_meta( $post->ID, 'wct_product_tabs', true ) );
            $tab_data = is_array( $tab_data ) ? $tab_data : array();

            // If we don't have tab data, we display things slightly differently
            $product_has_tabs = true;

            if ( empty( $tab_data ) ) {
                $product_has_tabs = false;
            }

            // Pull the saved array of reusable tabs
            $reusable_tab_options_array = get_option( 'wct_reusable_products_tabs_applied', array() );

            // Display the custom tab panel
            echo '<div id="wct_custom_product_tabs" class="panel wc-metaboxes-wrapper woocommerce_options_panel hidden">';
            echo    '<div class="options_group">';
            echo        '<div class="woocommerce_variations wc-metaboxes ui-sortable" data-edited="false"> ';
                            if ( $product_has_tabs === true ) {            
                                // Loop through all the tabs and add all components
                                $this->wct_generate_tab_html( $tab_data, $reusable_tab_options_array, $post );                                   
                            }

                            // Add duplicate container
                            $this->wct_generate_duplicate_html();                           

            echo        '</div>';
            echo    '</div>';

                    // Add a Saved Tab // Add Another Tab
            echo    $this->wct_display_add_tabs_container( $product_has_tabs );

                    // Hidden input field holding # of tabs
            echo    $this->wct_display_number_of_tabs( count( $tab_data ) );

            echo '</div>';
    	}

        /**
        * Generate the duplicate HTML block
        *
        * @since 1.0.0
        *
        */
        protected function wct_generate_duplicate_html() {
            // duplicate_this_row content
            echo '<div id="duplicate_this_row">';
            echo    '<div class="woocommerce_variation wc-metabox closed wct_tabs_section">';  
                        // Override Saved Tab checkbox & hidden input fields - Up & Down arrows && Remove Tab button (Duplicate)
            echo        $this->wct_display_button_holder_container_duplicate();
            echo        '<div class="woocommerce_variable_attributes wc-metabox-content" style="display: none;">';
            echo            '<div class="data">';

                                // Tab title input field
                                woocommerce_wp_text_input( array( 
                                        'id'          => 'hidden_duplicator_row_title' , 
                                        'label'       => __( 'Title', 'woocommerce_custom_tabs' ), 
                                        'description' => '', 
                                        'placeholder' =>  __( 'Custom Tab Title' , 'woocommerce_custom_tabs' ), 
                                        'class'       => 'wct_tabs_title_field wct_tabs_title_field_duplicate' ,
                                        'value'       => '',
                                    ) 
                                );

                                // WYSIWYG Content field
                                $this->wct_display_woocommerce_wp_wysiwyg_input_duplicate();

            echo            '</div>';
            echo        '</div>';
            echo    '</div>';
            echo '</div>';
        }

        /**
        * Generate the normal tab HTML block
        *
        * @since 1.0.0
        *
        * @param array | $tab_data              | Array of tab data
        * @param array | $reusable_tab_options  | Array of saved tab data
        * @param object| $post                  | The global $post object
        */
        protected function wct_generate_tab_html( $tab_data, $reusable_tab_options, $post ) {
            $i = 1;

            // Set up the initial display, by looping
            foreach ( $tab_data as $tab ) {

                $reusable_tab_flag = false;
                $reusable_tab_id   = '';

                // If $tab is in the array of reusable tabs, set flag
                if ( isset( $reusable_tab_options ) && isset( $reusable_tab_options[$post->ID] ) ) {

                    foreach( $reusable_tab_options[$post->ID] as $id => $reusable_tab_data ) {
                        if ( isset( $reusable_tab_data['tab_id'] ) && isset( $tab['id'] ) && $reusable_tab_data['tab_id'] === $tab['id'] ) {
                            $reusable_tab_flag = true;
                            $reusable_tab_id   = $reusable_tab_data['reusable_tab_id'];
                        }
                    }
                }
                echo    '<div class="woocommerce_variation wc-metabox closed wct_tabs_section">';  
                // Override Saved Tab checkbox & hidden input fields, Up & Down arrows, Remove Tab button
                echo        $this->wct_display_button_holder_container( $i, $reusable_tab_flag, $reusable_tab_id, $tab );

                echo        '<div class="woocommerce_variable_attributes wc-metabox-content" style="display: none;">
                                <div class="data">';
                                    // Tab Title input field
                                    $this->wct_display_woocommerce_wp_text_input( $i, $tab );

                                    // Tab content wysiwyg
                                    $this->wct_display_woocommerce_wp_wysiwyg_input( $i, $tab );
                echo            '</div>
                            </div>';
                echo    '</div>';
                
                $i++;
            }
        }

        /**
        * Call input field generation function and echo HTML to page
        *
        * @since 1.0.0
        *
        * @param int   | $i   | Counter for tab generating loop
        * @param array | $tab | Array of tab data
        */
        protected function wct_display_woocommerce_wp_text_input( $i, $tab ) {

            woocommerce_wp_text_input( array( 
                    'id'          => '_wct_custom_repeatable_product_tabs_tab_title_' . $i , 
                    'label'       => __( 'Tab Title', 'woocommerce_custom_tabs' ), 
                    'description' => '', 
                    'value'       => $tab['title'] , 
                    'placeholder' => __( 'Custom Tab Title' , 'woocommerce_custom_tabs' ), 
                    'class'       => 'wct_tabs_title_field'
                ) 
            );
        }

        /**
        * Call wp_editor wrapped function and echo HTML to page
        *
        * @since 1.0.0
        *
        * @param int   | $i   | Counter for tab generating loop
        * @param array | $tab | Array of tab data
        */
        protected function wct_display_woocommerce_wp_wysiwyg_input( $i, $tab ) {
            echo '<div class="form-field-tinymce _wct_custom_repeatable_product_tabs_tab_content_field _wct_custom_repeatable_product_tabs_tab_content_' . $i . '_field">';
                $this->wct_woocommerce_wp_wysiwyg_input( array(
                    'id'     => '_wct_custom_repeatable_product_tabs_tab_content_' . $i ,
                    'label'  => __( 'Content', 'woocommerce_custom_tabs' ),
                    'value'  => $tab['content'],
                    'style'  => 'width:100%;min-height:13rem;',
                    'class'  => 'wct_tabs_content_field',
                    'number' => $i
                ) );
            echo '</div>';
        }

        /**
        * Call input field generation function and echo HTML to page
        *
        * @since 1.0.0
        *
        * @param array | $tab | Array of tab data
        */
        protected function wct_display_woocommerce_wp_wysiwyg_input_duplicate() {
            
                $this->wct_woocommerce_wp_textarea_input( array( 
                        'id'     => 'hidden_duplicator_row_content' , 
                        'label'  => __( 'Content', 'woocommerce_custom_tabs' ), 
                        'style'  => 'width:100%; min-height:13rem;' , 
                        'class'  => 'wct_tabs_content_field', 
                    ) 
                );
            
        }

        /**
        * Generates a textarea field for hidden duplicate HTML block
        *
        * @param array | $field | Array of HTML field related values
        */
        private function wct_woocommerce_wp_textarea_input( $field ) {

            if ( ! isset( $field['placeholder'] ) ) $field['placeholder'] = '';
            if ( ! isset( $field['class'] ) ) $field['class'] = '';
            if ( ! isset( $field['value'] ) ) $field['value'] = '';

            echo '<p class="form-field-tinymce ' . $field['id'] . '_field"> <textarea class="' . $field['class'] . '" name="' . $field['id'] . '" id="' . $field['id'] . '" placeholder="' . $field['placeholder'] . '" rows="20" cols="40"' . (isset( $field['style'] ) ? ' style="' . $field['style'] . '"' : '') . '>' . $field['value'] . '</textarea> ';
            
            if ( isset( $field['description'] ) && $field['description'] ) {
                echo '<span class="description">' . $field['description'] . '</span>';
            }

            echo '</p>';
        }

        /**
        * Add duplicate button holder container HTML to page
        *
        * @since 1.0.0
        *
        * @return string HTML
        */
        protected function wct_display_button_holder_container_duplicate() {
            $return_html  = '';
            $return_html .= '<h3 class="button-holder hidden_duplicator_row_button_holder last-button-holder" alt="">';
            $return_html .=     '<a href="javascript:void(0)" class="edit_variation edit">Edit</a>';
            $return_html .=     '<a href="#" class="remove_variation delete remove_this_tab">Remove</a>';
            $return_html .=     '<div class="tips sort ui-sortable-handle"></div>';
            $return_html .=     '<strong class="wct_tab_title_">Custom Tab Title</strong>';
            $return_html .= '</h3>';

            return $return_html;
        }

        /**
        * Add 'Add Another Tab' and 'Add a Saved Tab' buttons to page
        *
        * @since 1.0.0
        *
        * @param bool | $product_has_tabs | flag indicating whether the product has any defined tabs
        * @return string HTML
        */
        protected function wct_display_add_tabs_container( $product_has_tabs ) {
            $return_html     = '';

            // If we don't have any tabs, then add some classes
            $classes_to_add  = ( $product_has_tabs === false ) ? '_wct_add_tab_center_new _wct_add_tab_center' : '';

            $return_html    .= '<div class="add_tabs_container ' . $classes_to_add . '">';
            $return_html    .=     '<a href="#" class="button-secondary _wct_add_tabs" id="add_new_tab">';
            $return_html    .=         __( 'Add New' , 'woocommerce_custom_tabs' );
            $return_html    .=     '</a>';
            $return_html    .=     '<input name="save" class="button button-primary" id="wct_save_custom_tabs" value="Save Tabs" type="button">';
            $return_html    .=     '<span id="wct_ajax_save_feedback"></span>';
            $return_html    .= '</div>';

            return $return_html;
        }

        /**
        * Add button holder container HTML to page
        *
        * @since 1.0.0
        *
        * @param int $i Counter for tab generating loop
        * @return string HTML
        */
        protected function wct_display_button_holder_container( $i, $reusable_tab_flag, $reusable_tab_id, $tab ) {
            $return_html  = '';
            $return_html .= '<h3 class="button-holder" alt="'. $i .'">';
            $return_html .=     '<a href="javascript:void(0)" class="edit_variation edit">Edit</a>';
            $return_html .=     '<a href="#" class="remove_variation delete remove_this_tab">Remove</a>';
            $return_html .=     '<div class="tips sort ui-sortable-handle"></div>';
            $return_html .=     '<strong class="wct_tab_title_'. $i .'">'. $tab['title'] .'</strong>';
            $return_html .= '</h3>';

            return $return_html;
        }

        /**
        * Add hidden input field for number of tabs to page
        *
        * @since 1.0.0
        *
        * @param string | $tab_count | value of tab content
        * @return string HTML
        */
        protected function wct_display_number_of_tabs( $tab_count ) {
            $return_html  = '';
            $return_html .= '<input type="hidden" value="' . $tab_count . '" id="number_of_tabs" name="number_of_tabs" >';

            return $return_html;
        }

        /**
        * Wrapper function for wp_editor
        *
        * @since 1.0.0
        * @param array | $field | Array of HTML field related values
        */
        private function wct_woocommerce_wp_wysiwyg_input( $field ) {

            if ( ! isset( $field['placeholder'] ) ) $field['placeholder'] = '';
            if ( ! isset( $field['class'] ) ) $field['class'] = '';
            if ( ! isset( $field['value'] ) ) $field['value'] = '';

            $editor_settings = array(
                'textarea_name' => $field['id'],
                'textarea_rows' => 8,
            );

            wp_editor( $field['value'], $field['id'], $editor_settings );

            if ( isset( $field['description'] ) && $field['description'] ) {
                echo '<span class="description">' . $field['description'] . '</span>';
            }
        }

    }
}

?>
