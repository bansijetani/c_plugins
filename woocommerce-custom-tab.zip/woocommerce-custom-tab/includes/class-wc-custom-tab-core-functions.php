<?php
/**
 * Woocommerce Custom Tab Core Functions
 *
 * @version 1.0.0
 * @package WC_CustomTabs\classes
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 *
 * @class WC_Custom_Tab_Core_Functions
 */
if ( ! class_exists( 'WC_Custom_Tab_Core_Functions' ) ) {

    /**
     * WC_Custom_Tab_Core_Functions class
     */
    class WC_Custom_Tab_Core_Functions {
        
        /**
         * WC_Custom_Tab_Core_Functions Constructor
         *
         * @since 1.0.0
         * @return void
         */
        public function __construct() {
            $this->wct_includes();
        }

        /**
         * Include required files
         *
         * @since 1.0.0
         * @return void
         */
        public function wct_includes() {
            include_once dirname( WCT_PLUGIN_DIR ) . '/includes/class-wc-custom-tab-admin.php';                       
            include_once dirname( WCT_PLUGIN_DIR ) . '/includes/class-wc-custom-tab-frontend.php';                       
        }        
        
    } 

}

if ( class_exists( 'WC_Custom_Tab_Core_Functions', false ) ) {
    return new WC_Custom_Tab_Core_Functions();
}
