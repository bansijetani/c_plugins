<?php
/**
 * Woocommerce Custom Tab Admin Functions
 *
 * @version 1.0.0
 * @package WC_CustomTabs\classes
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 *
 * @class WC_Custom_Tab_Admin
 */
if ( ! class_exists( 'WC_Custom_Tab_Admin' ) ) {
    class WC_Custom_Tab_Admin {

        /**
         * The single instance of the class.
         *
         * @var class object
         * @since 1.0.0
         */
        protected static $instance = null;

        /**
         * Main WC_Custom_Tab_Admin Instance.
         *
         * Ensures only one instance of WpContentLocker is loaded or can be loaded.
         *
         * @since 1.0.0
         * @return WC_Custom_Tab_Admin - Main instance.
         */

        public static function instance() {
            if ( is_null( self::$instance ) ) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        /**
         * WC_Custom_Tab_Admin Constructor.
         *
         * @since 1.0.0
         * @return void
         */
        public function __construct() {
            add_action( 'woocommerce_init', array( $this, 'wct_init_hooks' ) );       
        }

        /**
         * Include required action/filter here
         *
         * @since 1.0.0
         * @return void
         */
        public function wct_init_hooks() {

            // Enqueue scripts & styles
            add_action( 'admin_enqueue_scripts', array( $this, 'wct_enqueue_scripts' ), 10, 1 );

            // Add our Custom Product Tabs panel to the WooCommerce panel container
            add_action( 'woocommerce_product_write_panel_tabs', array( $this, 'wct_render_custom_product_tabs' ) );
            add_action( 'woocommerce_product_data_panels', array( $this, 'wct_product_page_custom_tabs_panel' ) );

            // Define our AJAX calls
            add_action( 'wp_ajax_wct_get_wp_editor', array( $this, 'wct_get_wp_editor' ) );
            add_action( 'wp_ajax_wct_save_product_tabs', array( $this, 'wct_save_product_tabs' ) );

        }

        /**
        * Enqueue scripts and styes
        *
        * @param string | $page | The slug of the page we're currently on
        */
        public function wct_enqueue_scripts( $page ) {   
            global $post;
            global $wp_version; 
            if ( $page === 'post-new.php' || $page === 'post.php' ) {
                if ( isset( $post->post_type ) &&  $post->post_type === 'product' ) {
                    
                    // Enqueue WordPress' built-in editor functions - added in WPv4.8
                    if ( function_exists( 'wp_enqueue_editor' ) ) {
                        wp_enqueue_editor();
                    }

                    wp_enqueue_style ( 'wct-admin-style', WCT_PLUGIN_URL  . '/assets/css/style-admin.css' );
                    wp_enqueue_script ( 'wct-admin-script', WCT_PLUGIN_URL  . '/assets/js/script-admin.js' );
                    wp_localize_script( 'wct-admin-script', 'repeatable_custom_tabs', array(
                        'loading_gif'                   => '<img src="' . admin_url( 'images/loading.gif' ) . '" alt="preloader" class="loading-wp-editor-gif custom-tabs-preloader" />',
                        'ajaxurl'                       => admin_url( 'admin-ajax.php' ),
                        'get_wp_editor_security_nonce'  => wp_create_nonce( 'wct_get_wp_editor_nonce' ),
                        'save_product_tabs_nonce'       => wp_create_nonce( 'wct_save_product_tabs_nonce' ),
                        'global_post_id'                => $post->ID,
                        'get_wp_editor_failure_message' => __( 'Sorry! An error has occurred while trying to retrieve the editor. Please refresh the page and try again.', 'woocommerce_custom_tabs' ),
                        'wp_version_four_eight'         => $wp_version >= '4.8',
                    ) );
                }
            }
        }

        /**
         * Adds a new tab to the Product Data postbox in the admin product interface
         *
         * @since 1.0
         * @return void
         */
        public function wct_render_custom_product_tabs() {
            echo '<li class="wct_product_tabs_tab">
                    <a href="#wct_custom_product_tabs">
                        <span>' . __( 'Custom Tabs', 'woocommerce_custom_tabs' ) . '</span>
                    </a>
                </li>';
        }

        /**
         * Adds the panel to the Product Data postbox in the product interface
         *
         * @since 1.0
         * @return void
         */
        public function wct_product_page_custom_tabs_panel() {

            // Require & instantiate our HTML class
            include_once dirname( WCT_PLUGIN_DIR ) . '/includes/class-wc-custom-tab-generate-html.php';
            $HTML = new WC_Custom_Tab_Generat_HTML();

            // Call our function to generate the HTML
            $HTML->wct_generate_html();
        }

        /**
        * [AJAX] Return wp_editor HTML
        *
        * @since 1.0
        *
        * @param string $_POST['textarea_id'] ID of the textarea that we're initializing wp_editor with
        * @param string $_POST['tab_content'] content to pre-supply the text editor with
        * @return string wp_editor HTML
        */
        public function wct_get_wp_editor() {

            // Verify nonce
            if ( ! check_ajax_referer( 'wct_get_wp_editor_nonce', 'security_nonce', false ) ) {
                wp_send_json_error();
            }

            // Get & sanitize the $_POST var textarea_id
            $textarea_id = filter_var( $_POST['textarea_id'], FILTER_SANITIZE_STRING );

            // Check if we have tab content
            $tab_content = isset( $_POST['tab_content'] ) ? $_POST['tab_content'] : '';

            // Set up options
            $wp_editor_options = array(
                'textarea_name' => $textarea_id,
                'textarea_rows' => 8,
            );

            // Return wp_editor HTML
            wp_editor( stripslashes( $tab_content ), $textarea_id, $wp_editor_options );
            exit;
        }

        /**
        * [AJAX] Save all tabs for the current product
        *
        * @since 1.0
        *
        * @param  string $_POST['post_id']      | ID of the current product (post)
        * @param  array  $_POST['product_tabs'] | array of all the tab data
        * @return object success w/ message || failure w/ message
        */
        public function wct_save_product_tabs() {

            // Verify the nonce
            if ( ! check_ajax_referer( 'wct_save_product_tabs_nonce', 'security_nonce', false ) ) {
                wp_send_json_error();
            }

            // Get our product id
            if ( isset( $_POST['post_id'] ) ) {
                $post_id = filter_var( $_POST['post_id'], FILTER_SANITIZE_NUMBER_INT );
            } else {

                // Fail gracefully...
                wp_send_json_error( array( 'message' => __( 'Could not find the product!', 'woocommerce_custom_tabs' ) ) );
            }

            // Save our tabs!
            $success = $this->wct_save_tabs( $post_id, $is_ajax = true );

            if ( $success === true ) {
                wp_send_json_success( array( 'message' => __( 'Your tabs have been saved', 'woocommerce_custom_tabs' ) ) );
            } else {
                wp_send_json_error( array( 'message' => __( 'Uh oh! Something went wrong with saving. Please try again.', 'woocommerce_custom_tabs' ) ) );
            }
        }

        /**
        * Save the tabs to the database
        *
        * @since 1.0
        *
        * @param int  | $post_id      | The ID of the post that has custom tabs
        * @param bool | $is_ajax_flag | A flag signifying whether we're calling this function from an AJAX call
        */
        protected function wct_save_tabs( $post_id, $is_ajax_flag ) {
            $tab_data = array();

            $number_of_tabs = $_POST['number_of_tabs'];

            // Create an array for tab_ids that we will use later
            $current_saved_tab_id_array = array();
            $remove_a_tab_from_reusable = false;

            // Fetch the reusable tab options (we'll use this later)
            $reusable_tab_options_array = get_option( 'wct_reusable_products_tabs_applied', array() );

            // Check if this tab has reusable tabs and set flag
            $post_has_reusable_tabs = false;
            if ( isset ( $reusable_tab_options_array[$post_id] ) ) {
                $post_has_reusable_tabs = true;
            }

            $i = 1;
            while( $i <= $number_of_tabs ) {

                // Deal with saving the tab content

                $tab_title   = isset( $_POST['_wct_custom_repeatable_product_tabs_tab_title_' . $i] ) ? stripslashes( $_POST['_wct_custom_repeatable_product_tabs_tab_title_' . $i] ) : '';
                $tab_content = isset( $_POST['_wct_custom_repeatable_product_tabs_tab_content_' . $i] ) ? stripslashes( $_POST['_wct_custom_repeatable_product_tabs_tab_content_' . $i] ) : '';

                if ( empty( $tab_title ) && empty( $tab_content ) ) {

                    // clean up if the custom tabs are removed
                    unset( $tab_data[$i] );

                } else {

                    $tab_id = '';

                    if ( $tab_title ) {
                        $tab_id = urldecode( sanitize_title( $tab_title ) );
                    }

                    // push the data to the array
                    $tab_data[$i] = array( 'title' => $tab_title, 'id' => $tab_id, 'content' => $tab_content );
                }

                $i++;
            }

            // Reset the array count, when items are removed
            $tab_data = array_values( $tab_data );

            // update the post data
            update_post_meta( $post_id, 'wct_product_tabs', $tab_data );

            if ( $is_ajax_flag === true ) {
                return true;
            }
        }

    }
}

if ( class_exists( 'WC_Custom_Tab_Admin', false ) ) {
    return new WC_Custom_Tab_Admin();
}
