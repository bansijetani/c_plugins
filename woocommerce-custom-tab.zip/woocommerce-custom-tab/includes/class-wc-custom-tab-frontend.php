<?php 
/**
 * Woocommerce Custom Tab Frontend Functions
 *
 * @version 1.0.0
 * @package WC_CustomTabs\classes
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 *
 * @class WC_Custom_Tab_FrontEnd
 */
if ( ! class_exists( 'WC_Custom_Tab_FrontEnd' ) ) {
	class WC_Custom_Tab_FrontEnd {

		 /**
         * WC_Custom_Tab_FrontEnd Constructor.
         *
         * @since 1.0.0
         * @return void
         */
		public function __construct() {
			add_action( 'woocommerce_init', array( $this, 'wct_init_hooks' ) );
		}

		/**
         * Include required action/filter here
         *
         * @since 1.0.0
         * @return void
         */
		public function wct_init_hooks() {

			// Add our custom product tabs section to the product page
			add_filter( 'woocommerce_product_tabs', array( $this, 'wct_add_custom_product_tabs' ) );
		}

		/**
		 * Add the custom product tab to the front-end single product page
		 *
		 * @since 1.0.0
		 * @param array  | $tabs | Array representing this product's current tabs
		 * @return array | Array of this product's current tabs plus our custom tabs
		 */
		public function wct_add_custom_product_tabs( $tabs ) {
			$product = wc_get_product();

			if ( empty( $product ) ) {
				return $tabs;
			}

			$product_id   = ( method_exists( $product, 'get_id' ) === true ) ? $product->get_id() : $product->ID;
			$product_tabs = maybe_unserialize( get_post_meta( $product_id, 'wct_product_tabs' , true ) );

			if ( is_array( $product_tabs ) && ! empty( $product_tabs ) ) {

				// Setup priorty to loop over, and render tabs in proper order
				$i = 25; 

				foreach ( $product_tabs as $tab ) {

					// Do not show tabs with empty titles on the front end
					if ( empty( $tab['title'] ) ) {
						continue;
					}

					$tab_key = $tab['id']; 

					$tabs[ $tab_key ] = array(
						'title'		=> $tab['title'],
						'priority'	=> $i++,
						'callback'	=> array( $this, 'wct_custom_product_tabs_panel_content' ),
						'content'	=> $tab['content']
					);
				}
				if ( isset( $tabs['reviews'] ) ) {

					// Make sure the reviews tab remains on the end (if it is set)
					$tabs['reviews']['priority'] = $i;
				}
			}

			/**
			* Filter: 'wct_filter_all_product_tabs'
			*
			* Generic filter that passes all of the tab info and the corresponding product. Cheers.
			*
			* Note: This passes all of the tabs for the current product, not just the Custom Product Tabs created by this plugin.
			*
			* @since 1.0.0
			* @param array  | $tab		| Array of $tab data arrays.
			* @param object | $product	| The WooCommerce product these tabs are for
			*/
			$tabs = apply_filters( 'wct_filter_all_product_tabs', $tabs, $product );

			return $tabs;
			
		}


		/**
		 * Render the custom product tab panel content for the given $tab
		 *
		 * @since 1.0.0
		 * @param string | $key | Current data key
		 * @param array  | $tab | Array of $tab data arrays.
		 **/
		public function wct_custom_product_tabs_panel_content( $key, $tab ) {

			$content                = '';
			$use_the_content_filter = apply_filters( 'wct_use_the_content_filter', true );

			if ( $use_the_content_filter === true ) {
				$content = apply_filters( 'the_content', $tab['content'] );
			} else {
				$content = apply_filters( 'wct_filter_main_tab_content', $tab['content'] );
			}

			$tab_title_html = '<h2 class="wct-custom-woo-tab-title wct-custom-woo-tab-title-' . urldecode( sanitize_title( $tab['title'] ) ) . '">' . $tab['title'] . '</h2>';

			echo apply_filters( 'wct_woocommerce_custom_repeatable_product_tabs_heading', $tab_title_html, $tab );
			echo apply_filters( 'wct_woocommerce_custom_repeatable_product_tabs_content', $content, $tab );
		}

	}
}

if ( class_exists( 'WC_Custom_Tab_FrontEnd', false ) ) {
    return new WC_Custom_Tab_FrontEnd();
}