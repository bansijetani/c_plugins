( function($){

  $(document).ready(function(){
    setTimeout( function() {
      wct_set_editor_specific_styles();
    }, 1000 );

    // Add a new tab
    $( document ).on( 'click' , '#add_new_tab' , function( e ) {  
      wct_add_new_tab( '' );
      e.preventDefault();
    });

    // Handle two tabs with the same name by creating an overlay and showing an error message
    jQuery( 'body' ).on( 'focusout', '.wct_tabs_title_field', function() {
      var current_element = jQuery( this );

      // If we have only one tab, don't bother
      if ( parseInt( jQuery("#number_of_tabs").val() ) === 1 ) {
        current_element.removeClass( '_wct_title_red_overlay' );
        current_element.parent( '.form-field' ).children( '._wct_duplicate_title_message' ).remove();
        return;
      }
      
      if( current_element.val() == '' ){ 
        current_element.addClass( '_wct_title_red_overlay' );
        current_element.parent( '.form-field' ).children( '._wct_duplicate_title_message' ).remove();
        current_element.parent( '.form-field' ).append( '<span class="_wct_duplicate_title_message"> Title is required! </span>');
        jQuery( '#wct_save_custom_tabs' ).addClass( 'disabled' );
        return;
      }else{
        current_element.parents('.woocommerce_variation').find( '[class^="wct_tab_title_"]' ).text( jQuery(this).val() );
        current_element.removeClass( '_wct_title_red_overlay' );
        current_element.parent( '.form-field' ).children( '._wct_duplicate_title_message' ).remove();
      } 

      // Current element ID and value
      var current_element_id  = jQuery( this ).attr( 'id' );
      var current_element_val = jQuery( this ).val();

      // Flag indicating whether we detected a duplicate
      var dupe_detected = false;

      // Loop through each title element
      jQuery( '.wct_tabs_title_field' ).each( function( index, element ) {

        // Make sure we're not looking at the current element (this) and that the element has a value
        if ( jQuery( element ).attr( 'id' ) != current_element_id && jQuery( element ).val() != '' ) {

          // If another title is the same as this one, add red overlay & message. Else, remove red overlay and message.
          if ( jQuery( element ).val().toLowerCase() === current_element_val.toLowerCase() ) {
            current_element.addClass( '_wct_title_red_overlay' );
            current_element.parent( '.form-field' ).children( '._wct_duplicate_title_message' ).remove();
            current_element.parent( '.form-field' ).append( '<span class="_wct_duplicate_title_message"> Please choose a unique tab name - duplicate tab names can create errors! </span>');
            jQuery( '#wct_save_custom_tabs' ).addClass( 'disabled' );
            dupe_detected = true;
          }

          // If we didn't find a dupe, remove the overlay classes && message
          if ( dupe_detected === false ) {
            jQuery( '._wct_title_red_overlay' ).removeClass( '_wct_title_red_overlay' );
            jQuery( '._wct_duplicate_title_message' ).remove();
            jQuery( '#wct_save_custom_tabs' ).removeClass( 'disabled' );
          }
        }
      });
    });

    // Remove tab
    $( document ).on( 'click' , '.remove_this_tab' , function( e ) {
      window.confirm('Are you sure you want to remove this tab?');       
      wct_remove_tab( $( this ) );
      e.preventDefault();
    });

    // Handle saving all the tabs
    $( document ).on( 'click' , '#wct_save_custom_tabs' , function( e ) {
      wct_save_tab();
      e.preventDefault();
    });

    // Drag and drop tabs
    $("#wct_custom_product_tabs .woocommerce_variations").sortable({     
      items: '.woocommerce_variation',
      cursor: 'move',
      axis: 'y',
      handle: ".sort",
      scrollSensitivity: 40,
      forcePlaceholderSize: !0,
      helper: "clone",
      start: function(e, ui) {
        $(ui.item).find('textarea').each(function () {
          wct_init_tynimac($(this).attr('id'));
          tinymce.execCommand('mceRemoveEditor', false, $(this).attr('id'));
        });
      },
      stop: function(e, ui) {
        $(ui.item).find('textarea').each(function () {
          wct_init_tynimac($(this).attr('id'));
          tinymce.execCommand('mceAddEditor', true, $(this).attr('id'));
        });
      }
    });

  })

})(jQuery)

/**
* Duplicate and transform hidden HTML to create a new tab
*
* @since 1.0
* @param string | tab_content | content to pre-populate the editor with
*/
function wct_add_new_tab( tab_content ) {
  // Disable buttons/arrows to help prevent wp_editor errors
  wct_toggle_controls( 'disable' );

  // Remove our center class
  jQuery( '#add_new_tab' ).parent( '.add_tabs_container' ).removeClass( '_wct_add_tab_center' );

  // Setup variables for use in generating a new tab
  var clone_container          = jQuery( '#duplicate_this_row' );
  var new_count                = parseInt( jQuery( '#number_of_tabs' ).val() ) + parseInt( 1 ); /* get new number of cloned element */
  var move_tab_content_buttons = jQuery( '#duplicate_this_row .button-holder' );
  var textarea_id              = '_wct_custom_repeatable_product_tabs_tab_content_' + new_count;
  var title_id                 = '_wct_custom_repeatable_product_tabs_tab_title_' + new_count;

  // Clone our hidden elements and change some classes and attributes
  clone_container.children( '.wct_tabs_section' ).each( function() {
    jQuery(this).clone().insertBefore('#duplicate_this_row').removeClass( 'hidden_duplicator_row_title_field hidden_duplicator_row_content_field hidden_duplicator_row_button_holder' ).addClass( 'new_duplicate_row' );
  }).promise().done( function() {

    // Change title classes
    jQuery( '.new_duplicate_row' ).find( 'input' ).each( function() {
      if ( jQuery( this ).is( 'input[name="hidden_duplicator_row_title"]' ) ) {
        jQuery( this ).attr( 'name' , title_id ).removeClass( 'wct_tabs_title_field_duplicate' ).attr( 'id' , title_id ).parents( 'p' ).addClass( title_id + '_field' )
                .removeClass( 'hidden_duplicator_row_title_field' ).find( 'label' ).removeAttr( 'for' ).attr( 'for', title_id + '_field' );
      }
    });

    // Change content classes
    jQuery( '.new_duplicate_row' ).find( 'textarea' ).each( function() {
      if ( jQuery( this ).is( 'textarea[name="hidden_duplicator_row_content"]' ) ) {
        jQuery( this ).parent( '.form-field-tinymce' ).addClass( '_wct_custom_repeatable_product_tabs_tab_content_field ' + textarea_id );
        jQuery( this ).attr( 'name' , textarea_id ).attr( 'id' , textarea_id ).parent( 'div' ).addClass( textarea_id + '_field' ).removeClass( 'hidden_duplicator_row_content_field' )
              .find( 'label' ).removeAttr( 'for' ).attr( 'for', textarea_id + '_field' );
      }
    });



    // Change button holder classes
    jQuery( '.new_duplicate_row .button-holder' ).attr( 'alt', new_count );
    jQuery( '.new_duplicate_row' ).find( '.wct_override_reusable_tab_container' ).attr( 'id', '_wct_override_reusable_tab_container_' + new_count );
    jQuery( '.new_duplicate_row' ).find( '.wct_override_reusable_tab_container' ).attr( 'id', '_wct_override_reusable_tab_container_' + new_count );
    jQuery( '.new_duplicate_row' ).find( '.wct_tab_title_' ).addClass('wct_tab_title_' + new_count).removeClass('wct_tab_title_');


    // Set the new number of tabs value
    jQuery( '#number_of_tabs' ).val( new_count );

    // Append the divider between tabs
    if ( new_count > 1 ) {
      // jQuery( '.new_duplicate_row' ).first().before( '<div class="wct-custom-tab-divider"></div>' );
    }
  });

  // Retrieve wp_editor HTML, the method to retrieve is dependent on WP version because WP4.8 introduced some new editor methods
  
  wct_toggle_controls( 'enable' );
  // if ( parseInt( repeatable_custom_tabs.wp_version_four_eight ) === 1 ) {
  //   wct_get_wp_editor_foureight( textarea_id, true, tab_content );
  // } else {
    // Add a loading gif until AJAX returns
    jQuery( '.' + textarea_id ).html( repeatable_custom_tabs.loading_gif );

    wct_get_wp_editor_ajax( textarea_id, true, tab_content );
  // }
  wct_set_editor_specific_styles();
  jQuery( '#duplicate_this_row' ).find( 'input[type="hidden"]' ).removeAttr( 'name' );

  // Remove some classes
  jQuery( '.last-button-holder' ).removeClass( 'last-button-holder' );
  jQuery( '.new_duplicate_row' ).removeClass( 'new_duplicate_row' );
  
}

/**
* Remove tab from the list
*
* @since 1.0
* @param string | clicked_ele | content to remove
*/
function wct_remove_tab( clicked_ele ){
  // We remove the last tab and apply that content
  var clicked_button      = clicked_ele;
  var clicked_position    = clicked_button.parents( '.button-holder' ).attr( 'alt' );
  var last_post_position  = jQuery( '#number_of_tabs' ).val();
  var tab_title_prefix    = '_wct_custom_repeatable_product_tabs_tab_title_';
  var tab_content_prefix  = '_wct_custom_repeatable_product_tabs_tab_content_';

  // If we're removing the last tab already, skip this step
  // If not, then swap all the content so the last tab is empty
  if ( clicked_position !== last_post_position ) {

    // Apply the content of the subsequent posts to the correct boxes
    var x = parseInt( clicked_position );
    while ( x < last_post_position ) {
      var tab_title       = '';
      var tab_content     = '';
      var next_tab_number = x + 1;

      // Switch tab title
      tab_title      = jQuery( '#' + tab_title_prefix + next_tab_number ).val();
      main_tab_title = jQuery( '.wct_tab_title_' + next_tab_number ).text();
      
      jQuery( '#' + tab_title_prefix + x ).val( tab_title );
      jQuery( '.wct_tab_title_' + x ).text();
      jQuery( '.wct_tab_title_' + x ).text( main_tab_title );      

      tab_content = wct_get_content_from_wysiwyg( tab_content_prefix + next_tab_number );
      wct_set_content_for_wysiwyg( tab_content_prefix + x, tab_content );

      x++;
    }
  }

  clicked_button.parents('.woocommerce_variation').addClass('closed').removeClass('open').find('.woocommerce_variable_attributes').css({'display':'none'});


  // Now remove the last tab (we always remove the last tab to prevent WYSIWYG errors)

  // Set up our id and name vars
  var tab_title_prefix    = '_wct_custom_repeatable_product_tabs_tab_title_';
  var tab_content_prefix  = '_wct_custom_repeatable_product_tabs_tab_content_';
  var removed_textarea_id = tab_content_prefix + last_post_position;

  // Set up our DOM elements to be removed
  var tab_title_to_remove                       = jQuery( '.' + tab_title_prefix + last_post_position + '_field' );
  var tab_content_to_remove                     = jQuery( '.' + tab_content_prefix + last_post_position );
  var button_holder_to_remove                   = jQuery( '.button-holder[alt="' + last_post_position + '"]' );
  var woocommerce_variable_attributes_to_remove = jQuery( '.button-holder[alt="' + last_post_position + '"]' ).parent('.woocommerce_variation');
  var number_of_tabs                            = parseInt( last_post_position ) - parseInt( 1 );

  // Destroy our tinymce instance (this enables us to re-add it later if we need to)
  if ( typeof( tinymce ) != 'undefined' ) {
    tinymce.execCommand( 'mceRemoveEditor', false, removed_textarea_id );
  }

  // Remove the DOM elements
  tab_title_to_remove.remove();
  tab_content_to_remove.remove();
  jQuery( '.' + tab_content_prefix + last_post_position + '_field' ).remove();
  button_holder_to_remove.remove();
  woocommerce_variable_attributes_to_remove.remove();

  // Store the new number of tabs
  jQuery( '#number_of_tabs' ).val( number_of_tabs );

  // If we've removed all the tabs, let's add a class to the Add Another Tab button so we can style it

  if ( parseInt( number_of_tabs ) === 0 ) {
      jQuery( '#add_new_tab' ).parent( '.add_tabs_container' ).addClass( '_wct_add_tab_center' );        
  }
}

/**
* Save all custom tabs
*
* @since 1.0
*/
function wct_save_tab(){
  // If we've added the disabled class, do not go further
  if ( jQuery( '#wct_save_custom_tabs' ).hasClass( 'disabled' ) === true ) {
    return;
  }
  // Disable button until we get back from AJAX -- this helps prevent multiple button clicks
  jQuery( '#wct_save_custom_tabs' ).addClass( 'disabled' );

  // Fade out our feedback message...
  jQuery( '#wct_ajax_save_feedback' ).fadeOut();

  // Number of tabs
  var number_of_tabs = jQuery( '#number_of_tabs' ).val();

  // Create data object for AJAX call
  var data = {
    'action': 'wct_save_product_tabs',
    'post_id': repeatable_custom_tabs.global_post_id,
    'number_of_tabs': number_of_tabs,
    'security_nonce': repeatable_custom_tabs.save_product_tabs_nonce
  };

  var error_detected = false;
  // We're going to collect all the data and send it to the server as if it were a form submission
  // So data object should have all the relevant fields like: field_name => field_value
   jQuery('.woocommerce_variable_attributes').each(function(i){
    i += 1;
    if( jQuery(this).find( 'input[name^="_wct_custom_repeatable_product_tabs_tab_title_"]' ).val() == '' ){      

      jQuery(this).find( 'input[name^="_wct_custom_repeatable_product_tabs_tab_title_"]' ).addClass( '_wct_title_red_overlay' );
      jQuery(this).find( 'input[name^="_wct_custom_repeatable_product_tabs_tab_title_"]' ).parent( '.form-field' ).children( '._wct_duplicate_title_message' ).remove();
      jQuery(this).find( 'input[name^="_wct_custom_repeatable_product_tabs_tab_title_"]' ).parent( '.form-field' ).append( '<span class="_wct_duplicate_title_message"> Title is required! </span>');
      jQuery(this).find( 'input[name^="_wct_custom_repeatable_product_tabs_tab_title_"]' ).parents('.woocommerce_variation').addClass('open').removeClass('closed').find('.woocommerce_variable_attributes').css({'display':'block'});

      jQuery( '#wct_save_custom_tabs' ).removeClass( 'disabled' );
      error_detected = true;
    }
    // Title
    data['_wct_custom_repeatable_product_tabs_tab_title_' + i] = jQuery(this).find( 'input[name^="_wct_custom_repeatable_product_tabs_tab_title_"]' ).val();

    // Content
    data['_wct_custom_repeatable_product_tabs_tab_content_' + i] = wct_get_content_from_wysiwyg( jQuery(this).find( 'textarea[name^="_wct_custom_repeatable_product_tabs_tab_content_"]' ).attr('id'));
  })

  if( error_detected == false ){
    jQuery.post( repeatable_custom_tabs.ajaxurl, data, function( response ) {
      var feedback_class = '';
      if ( typeof( response.success ) !== 'undefined' ) {
        if ( response.success === true ) {
          feedback_message_class = 'wct_save_success';
        } else if ( response.success === false ) {
          feedback_message_class = 'wct_save_failure';
        }
      }
      if ( typeof( response.data ) !== 'undefined' && typeof( response.data.message ) !== 'undefined' ) {
        jQuery( '#wct_ajax_save_feedback' ).removeClass().addClass( feedback_message_class ).text( response.data.message ).fadeIn().delay( '2000' ).fadeOut();
      }

      // Remove disabled class
      jQuery( '#wct_save_custom_tabs' ).removeClass( 'disabled' );
    });
  }
  
}

/**
* @summary Toggle disabling/hiding of UI buttons, this prevents potentially breaking the UI while AJAX is returning
*
* @since 1.0
*
* @param string | toggle_enable | 'disable' to disable/hide, 'enable' to enable/show
*
*/
function wct_toggle_controls( toggle_enable ) {
  if ( toggle_enable === 'disable' ) {
    jQuery( '.remove_this_tab' ).attr( 'disabled', 'disabled' );
    jQuery( '#add_new_tab' ).attr( 'disabled', 'disabled' );
    jQuery( '._wct_apply_a_saved_tab' ).attr( 'disabled', 'disabled' );
    jQuery( '.move-tab-data-up' ).hide();
    jQuery( '.move-tab-data-down' ).hide();
  } else {
    jQuery( '.remove_this_tab' ).removeAttr( 'disabled' );
    jQuery( '#add_new_tab' ).removeAttr( 'disabled' );
    jQuery( '._wct_apply_a_saved_tab' ).removeAttr( 'disabled' )
    jQuery( '.move-tab-data-up' ).show();
    jQuery( '.move-tab-data-down' ).show();   
  }
}

/**
  * @summary Fetch the wp_editor HTML via AJAX.
  *
  * @since 1.0
  *
  * @param string | textarea_id  | ID of the textarea where we're initializing the WYSIWYG editor
  * @param bool   | product_page | bool indicating whether we're on the product page (true) or settings page (false)
  * @param string | tab_content  | String to pre-populate the editor with content
  *
  * @return bool
  */
function wct_get_wp_editor_ajax( textarea_id, product_page, tab_content ) {
    
    // Create data object for AJAX call
    var data = {
      'action': 'wct_get_wp_editor',
      'textarea_id': textarea_id,
      'tab_content': tab_content,
      'security_nonce': repeatable_custom_tabs.get_wp_editor_security_nonce
    };

    // AJAX
    jQuery.post( repeatable_custom_tabs.ajaxurl, data, function( response ) {

      // Re-enable buttons / arrows
      wct_toggle_controls( 'enable' );

      // If call failed, show error message
      if ( typeof( response.success ) !== 'undefined' && response.success === false ) {
        jQuery( '.' + textarea_id ).html( '<p>' + repeatable_custom_tabs.get_wp_editor_failure_message + '</p>' );

        return false;
      }

      // Add wp_editor HTML to the page
      jQuery( '.' + textarea_id ).html( response ).addClass( '_wct_custom_repeatable_product_tabs_tab_content_field _wct_custom_repeatable_product_tabs_tab_content_field_dynamic' );

      wct_set_editor_specific_styles();

      // Initialize quicktags (for working in 'Text tab' mode)
      if ( typeof( QTags ) !== 'undefined' ) {
        quicktags( textarea_id );
        QTags._buttonsInit();
      }

      // These are WordPress default editor settings, retrieved from wp-includes\class-wp-editor.php
      // The `setup:` function is not part of the WordPress core, but the default styles were not being applied
      wct_init_tynimac(textarea_id);

      //Initialize tinymce
      if( typeof( tinymce ) != 'undefined' ) {
        tinymce.execCommand( 'mceAddEditor', false, textarea_id );
      }

      jQuery('#'+ textarea_id +'-html').trigger('click');
      
      return true;  
    });
  }

/**
  * @summary Set the wp_editor HTML
  *
  * @since 1.0
  *
  * @param string | textarea_id  | ID of the textarea where we're initializing the WYSIWYG editor
  * @param bool   | product_page | bool indicating whether we're on the product page (true) or settings page (false)
  * @param string | tab_content  | String to pre-populate the editor with content
  *
  * @return bool
  */
function wct_get_wp_editor_foureight( textarea_id, product_page, tab_content ) {
  
  if ( ! wp || ! wp.editor || ! wp.editor.initialize ) {
    wct_get_wp_editor_ajax( textarea_id, product_page, tab_content );
    return false;
  }
  
  // Re-enable buttons / arrows
  wct_toggle_controls( 'enable' );

  var settings = {
    tinymce: {
      branding: false,
      theme: 'modern',
      skin: 'lightgray',
      language: 'en',
      formats: {
        alignleft: [
          { selector: 'p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li', styles: { textAlign:'left' } },
          { selector: 'img,table,dl.wp-caption', classes: 'alignleft' }
        ],
        aligncenter: [
          { selector: 'p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li', styles: { textAlign:'center' } },
          { selector: 'img,table,dl.wp-caption', classes: 'aligncenter' }
        ],
        alignright: [
          { selector: 'p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li', styles: { textAlign:'right' } },
          { selector: 'img,table,dl.wp-caption', classes: 'alignright' }
        ],
        strikethrough: { inline: 'del' }
      },
      relative_urls: false,
      remove_script_host: false,
      convert_urls: false,
      browser_spellcheck: true,
      fix_list_elements: true,
      entities: '38,amp,60,lt,62,gt',
      entity_encoding: 'raw',
      keep_styles: false,
      paste_webkit_styles: 'font-weight font-style color',
      preview_styles: 'font-family font-size font-weight font-style text-decoration text-transform',
      end_container_on_empty_block: true,
      wpeditimage_disable_captions: false,
      wpeditimage_html5_captions: true,
      plugins: 'charmap,colorpicker,hr,lists,media,paste,tabfocus,textcolor,fullscreen,wordpress,wpautoresize,wpeditimage,wpemoji,wpgallery,wplink,wpdialogs,wptextpattern,wpview',
      menubar: false,
      wpautop: true,
      indent: false,
      resize: true,
      theme_advanced_resizing: true,
      theme_advanced_resize_horizontal: false,
      statusbar: true,
      toolbar1: 'formatselect,bold,italic,bullist,numlist,blockquote,alignleft,aligncenter,alignright,link,unlink,wp_adv',
      toolbar2: 'strikethrough,hr,forecolor,pastetext,removeformat,charmap,outdent,indent,undo,redo,wp_help',
      toolbar3: '',
      toolbar4: '',
      tabfocus_elements: ':prev,:next',
      // width: '100%',
      // body_class: 'id post-type-post post-status-publish post-format-standard',
      setup: function( editor ) {
        editor.on( 'init', function() {
          this.getBody().style.fontFamily = 'Georgia, "Times New Roman", "Bitstream Charter", Times, serif';
          this.getBody().style.fontSize = '16px';
          this.getBody().style.color = '#333';
          if ( tab_content.length > 0 ) {
            this.setContent( tab_content );
          }
        });
      },
    },
    quicktags: {
      buttons:"strong,em,link,block,del,ins,img,ul,ol,li,code,more,close"
    }
  }
  
  wp.editor.initialize( textarea_id, settings );

  // After tinymce is initialized, let's check if we need to disable the box (because it's a saved tab)
  var tab_number = wct_get_tab_number_from_id( textarea_id );

  // Add an 'Add Media' button
  // The plugin is included with the instantiation of the editor but there is no HTML button to trigger the associated functions
  var add_media_button = '<div id="wp-' + textarea_id + '-media-buttons" class="wp-media-buttons"> \
    <button type="button" id="insert-media-button" class="button insert-media add_media" data-editor="' + textarea_id + '"><span class="wp-media-buttons-icon"></span> Add Media</button>\
  </div>';
  jQuery( '#wp-_wct_custom_repeatable_product_tabs_tab_content_' + tab_number + '-wrap > .wp-editor-tools' ).prepend( add_media_button );
  
  return true;
}

/**
* @summary Get the numerical ID from a string ID
*
* @since 1.0
* @param string  | id_string  | an id of the form this_is_an_id_10
* @return string | tab_number | the numerical suffix of the string id passed in
*/ 
function wct_get_tab_number_from_id( id_string ) {
  return id_string.slice( ( id_string.lastIndexOf( '_' ) + 1 ) );
}

/**
* Retrieve the content from the wp_editor
*
* @since 1.0
*
* @param  string | editor_id | the id of the editor (without the prefacing #)
* @return string | content   | the content of the editor
*/
function wct_get_content_from_wysiwyg( editor_id ) {

  var content = '';

  // Check if tinymce is initialized, and if our instance is known
  if ( tinymce !== 'undefined' && tinymce.get( editor_id ) !== null ) {

    // Store the content
    content = tinymce.get( editor_id ).getContent();

    // If we don't have any content, check the textarea for a value and use it
    if ( content.length === 0 && jQuery( '#' + editor_id ).val().length > 0 ) {
      content = jQuery( '#' + editor_id ).val();
    }
  } else {

    // If tinymce is not initialized, try getting the content from the textarea value
    content = jQuery( '#' + editor_id ).val();
  }

  return content;
}

/**
* Set the content for the wp_editor
*
* @since 1.0
*
* @param  string | editor_id | the id of the editor (without the prefacing #)
* @param  string | content   | the content to supply the editor with
*/
function wct_set_content_for_wysiwyg( editor_id, content ) {
  
  // Check if tinymce is initialized, and if our instance is known
  if ( tinymce !== 'undefined' && tinymce.get( editor_id ) !== null ) {

    // If it's initialized, we can just set the content from here using setContent()
    tinymce.get( editor_id ).setContent( content );

    // tinyMCE stores the value in both places, so we need to set the textarea content from here too
    jQuery( '#' + editor_id ).val( content );
  } else {

    // Else we need to set the value using the textarea's val
    jQuery( '#' + editor_id ).val( content );
  }
}

/**
* Set custom styles to the wp-editor
*
* @since 1.0
*/
function wct_set_editor_specific_styles() {
  jQuery( 'textarea[name^="_wct_custom_repeatable_product_tabs_tab_content_"]' ).each( function() {
    jQuery( this ).addClass( 'wct_custom_editor_styles' );
  });
}

function wct_init_tynimac( id ){
  tinymce.init({
    branding: false,
    selector: '#' + id,
    theme: 'modern',
    skin: 'lightgray',
    language: 'en',
    formats: {
      alignleft: [
        { selector: 'p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li', styles: { textAlign:'left' } },
        { selector: 'img,table,dl.wp-caption', classes: 'alignleft' }
      ],
      aligncenter: [
        { selector: 'p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li', styles: { textAlign:'center' } },
        { selector: 'img,table,dl.wp-caption', classes: 'aligncenter' }
      ],
      alignright: [
        { selector: 'p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li', styles: { textAlign:'right' } },
        { selector: 'img,table,dl.wp-caption', classes: 'alignright' }
      ],
      strikethrough: { inline: 'del' }
    },
    relative_urls: false,
    remove_script_host: false,
    convert_urls: false,
    browser_spellcheck: true,
    fix_list_elements: true,
    entities: '38,amp,60,lt,62,gt',
    entity_encoding: 'raw',
    keep_styles: false,
    paste_webkit_styles: 'font-weight font-style color',
    preview_styles: 'font-family font-size font-weight font-style text-decoration text-transform',
    end_container_on_empty_block: true,
    wpeditimage_disable_captions: false,
    wpeditimage_html5_captions: true,
    plugins: 'charmap,colorpicker,hr,lists,media,paste,tabfocus,textcolor,fullscreen,wordpress,wpautoresize,wpeditimage,wpemoji,wpgallery,wplink,wpdialogs,wptextpattern,wpview',
    resize: true,
    menubar: false,
    wpautop: true,
    indent: false,
    toolbar1: 'formatselect,bold,italic,bullist,numlist,blockquote,alignleft,aligncenter,alignright,link,unlink,wp_adv',
    toolbar2: 'strikethrough,hr,forecolor,pastetext,removeformat,charmap,outdent,indent,undo,redo,wp_help',
    toolbar3: '',
    toolbar4: '',
    tabfocus_elements: ':prev,:next',
    body_class: 'id post-type-post post-status-publish post-format-standard',
    setup: function( editor ) {
      editor.on( 'init', function() {
        this.getBody().style.fontFamily = 'Georgia, "Times New Roman", "Bitstream Charter", Times, serif';
        this.getBody().style.fontSize = '16px';
        this.getBody().style.color = '#333';
      });
    }
  });
}