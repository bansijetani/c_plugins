<?php
/**
 * Plugin Name: Woocommerce Custom Tab
 * Plugin URI: #
 * Description: Plugin - add new custom tabs for products in Woocommerce.
 * Version: 1.0
 * Author: Codept Solutions
 * Author URI: https://codeptsolutions.com
 * Text Domain: woocommerce_custom_tabs
 *
 * @package WC_CustomTabs
*/


// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'WCT_PLUGIN_DIR' ) ) {
    define( 'WCT_PLUGIN_DIR', __FILE__ );
}

if ( ! defined( 'WCT_PLUGIN_URL' ) ) {
    define( 'WCT_PLUGIN_URL', untrailingslashit( plugins_url( '/', WCT_PLUGIN_DIR ) ) );
}

if ( ! defined( 'WCT_VERSION' ) ) {
    define( 'WCT_VERSION', '1.0.0' );
}

if ( ! defined( 'WCT_TIME_INTERVAL_DEFAULT' ) ) {
    define( 'WCT_TIME_INTERVAL_DEFAULT', 4320 );
}

add_action( 'plugins_loaded', 'wct_constructor', 15 );


/**
 * Plugin loaded.
 *
 * @return void
 * @since 1.0
 */
function wct_constructor() {
    global $woocommerce;

    $plugin = plugin_basename( __FILE__ );
    if ( ! isset( $woocommerce ) || ! function_exists( 'WC' ) ) {
        add_action( 'admin_notices', 'wct_install_woocommerce_admin_notice' );
        return;
    }

    // Include the main Plugin class.
    if ( ! class_exists( 'Woocommerce_Variation_Swatches', false ) ) {
        include_once dirname( WCT_PLUGIN_DIR ) . '/includes/class-wc-custom-tab-core-functions.php';
    }
   
}

/**
 * WooCommerce install admin notice.
 *
 * @return void
 * @since 1.0
 */
function wct_install_woocommerce_admin_notice() {
    ?>
    <div class="error">
        <p><?php esc_html_e( "Please Install and Activate WooCommerce plugin, without that this plugin can't work.", 'woocommerce-custom-tab' ); ?></p>
    </div>
    <?php
}



?>