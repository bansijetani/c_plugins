<?php
/**
 * Plugin Name: Woocommerce Default Checkout Editor
 * Plugin URI: #
 * Description: Plugin default checkout editor to manage default checkout editor in WooCommerce.
 * Version: 1.0
 * Author: Codept Solutions
 * Author URI: https://codeptsolutions.com
 * Text Domain: woocommerce_default_checkout_editor
 * WC tested up to: 7.5.1
 * Tested up to:  6.2.0
 * 
 * @package Woo_Dce
**/

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'WDCE_PLUGIN_DIR' ) ) {
    define( 'WDCE_PLUGIN_DIR', __FILE__ );
}

if ( ! defined( 'WDCE_PLUGIN_URL' ) ) {
    define( 'WDCE_PLUGIN_URL', untrailingslashit( plugins_url( '/', WDCE_PLUGIN_DIR ) ) );
}

if ( ! defined( 'WDCE_VERSION' ) ) {
    define( 'WDCE_VERSION', '1.0.0' );
}

if ( ! defined( 'WDCE_TIME_INTERVAL_DEFAULT' ) ) {
    define( 'WDCE_TIME_INTERVAL_DEFAULT', 4320 );
}

if ( ! defined( 'WC_MMQ_PREFIX' ) ) {
    define( 'WC_MMQ_PREFIX', 'TEST' );
}

add_action( 'plugins_loaded', 'wdce_constructor', 15 );

/**
 * Plugin loaded.
 *
 * @return void
 * @since 1.0
 */
function wdce_constructor() {
    global $woocommerce;

    $plugin = plugin_basename( __FILE__ );
    if ( ! isset( $woocommerce ) || ! function_exists( 'WC' ) ) {
        add_action( 'admin_notices', 'wdce_install_woocommerce_admin_notice' );
        return;
    }

    // Include the main Plugin class.
    if ( ! class_exists( 'Woocommerce_Default_Checkout_Editor', false ) ) {
        include_once dirname( WDCE_PLUGIN_DIR ) . '/includes/class-woocommerce-default-checkout-editor.php';
    }

    add_filter( "plugin_action_links_$plugin", 'wdce_settings_link' );
}

/**
 * WooCommerce install admin notice.
 *
 * @return void
 * @since 1.0
 */
function wdce_install_woocommerce_admin_notice() {
?>
    <div class="error">
        <p><?php esc_html_e( 'Woocommerce Default Checkout Editor for WooCommerce is enabled but not effective. It requires WooCommerce in order to work.', 'woocommerce_default_checkout_editor' ); ?></p>
    </div>
<?php
}

/**
 * Add settings link of plugin
 *
 * @param $links settings link of plugin in plugin listing page.
 *
 * @return $links.
 * @since  1.0
 */
function wdce_settings_link( $links ) {
    $settings_text = esc_html__( 'Settings', 'woocommerce_default_checkout_editor' );
    $settings_link = '<a href="admin.php?page=woocommerce_default_checkout_editor_forms"> ' . $settings_text . '</a>';
    array_unshift( $links, $settings_link );
    return $links;
}
?>