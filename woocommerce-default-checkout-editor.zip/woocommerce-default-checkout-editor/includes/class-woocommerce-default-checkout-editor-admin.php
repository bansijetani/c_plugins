<?php
/**
 * Set Woocommerce Default Checkout Editor
 * 
 * @package Woo_Dce
 *
 * @since 1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Woocommerce_Default_Checkout_Editor_Admin Class.
 * @since 1.0
 */

class Woocommerce_Default_Checkout_Editor_Admin {

    /**
     * Constructer Function
     *
     * @since 1.0
     * @return void
     */
    public function __construct(){
        $this->wdce_init_hooks();
    }

    /**
     * Include required action/filter here
     * 
     * @since 1.0
     * @return void
     */
    public function wdce_init_hooks() {
        add_action( 'admin_enqueue_scripts', array( $this,'wdce_enqueue_styles' ) );
        add_action( 'admin_menu', array( $this,'wdce_custom_submenu_page' ), 50 );
    }
    
     /**
     * Enqueue a script in the WordPress admin on edit.php
     * 
     * @since 1.0
     * @return void
     */
    public function wdce_enqueue_styles() {
        wp_enqueue_style( 'woocommerce_admin_styles' );
        wp_enqueue_style( 'wdce-admin-style', WDCE_PLUGIN_URL . '/assets/css/wdce-admin-style.css' );
        wp_enqueue_script( 'wdce_admin_js', WDCE_PLUGIN_URL . '/assets/js/wdce_admin.js' );
    }

    /**
     * Adds a submenu page under a Woocommerce page parent.
     * 
     *
     * @since 1.0
     * @return void
     */
    public function wdce_custom_submenu_page() {
        add_submenu_page( 'woocommerce', __('Woocommerce Default Checkout Editor', 'woocommerce_default_checkout_editor'), __('Checkout Form', 'woocommerce_default_checkout_editor'), 'manage_options', 'woocommerce_default_checkout_editor_forms', array($this, 'wdce_custom_submenu_page_callback'));
    }

    /**
     * Woocommerce Default Checkout Editor Page content.
     * 
     * @since 1.0
     * @return void
     */
    public function wdce_custom_submenu_page_callback() {
        $admin = new Woocommerce_Default_Checkout_Editor_General_Setting();
        echo '<div class="wrap">';
        echo '<h2>Woocommerce Default Checkout Editor</h2>';
        $admin->wdce_checkout_types_urls();
        echo '<div class="wdce-wrap">';
        $admin->wdce_woocommerce_listing_billing_fields();
        echo '</div>';
        echo '</div>';
    } 
}

if ( class_exists( 'Woocommerce_Default_Checkout_Editor_Admin', false ) ) {
    return new Woocommerce_Default_Checkout_Editor_Admin();
}
?>