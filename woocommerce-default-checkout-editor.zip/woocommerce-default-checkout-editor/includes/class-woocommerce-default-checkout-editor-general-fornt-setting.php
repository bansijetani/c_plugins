<?php

/**
 * Set Woocommerce Default Checkout Editor
 * 
 * @package Woo_Dce
 *
 * @since 1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Woocommerce_Default_Checkout_Editor_General_Setting Class.
 * @since 1.0
 */

class Woocommerce_Default_Checkout_Editor_General_Fornt_Setting {

    /**
     * Constructer Function
     *
     * @since 1.0
     * @return void
     */
    public function __construct() {
        $this->wdce_init_hooks();
    }

    /**
     * Include required action/filter here
     * 
     * @since 1.0
     * @return void
     */
    public function wdce_init_hooks() {
        add_filter('woocommerce_get_country_locale_default', array( $this, 'wdce_prepare_country_locale' ) );
        add_filter('woocommerce_get_country_locale_base', array( $this, 'wdce_prepare_country_locale' ) );
        add_filter('woocommerce_get_country_locale', array( $this, 'wdce_get_country_locale' ) );

        add_filter( 'woocommerce_billing_fields', array( $this, 'wdce_woocommerce_billing_fields' ), 999 );
        add_filter( 'woocommerce_shipping_fields', array( $this, 'wdce_woocommerce_shipping_fields'), 999 );

        add_action('wp_enqueue_scripts', array( $this, 'wdce_enqueue_styles_and_scripts' ) );
    }

    /**
     * Override the default country selections after a country is chosen 
     * 
     * @param array $fields default country selections
     * @since 1.0
     * @return array $fields modified countrty selections
     */
    public function wdce_prepare_country_locale( $fields ) {
        if( is_array( $fields ) ){
            foreach( $fields as $key => $props ){

                if( isset( $props['label'] ) ){
                    unset( $fields[$key]['label'] );
                }

                if( isset( $props['placeholder'] ) ){
                    unset( $fields[$key]['placeholder'] );
                }

                if( isset( $props['class'] ) ) {
                    unset( $fields[$key]['class'] );
                }
                
                if( isset( $props['priority'] ) ){
                    unset( $fields[$key]['priority'] );
                }

                if( isset( $props['required'] ) ){
                    unset( $fields[$key]['required'] );
                }
            }
        }
        return $fields;
    }

    /**
     * Override the default country selections after a country is chosen 
     * 
     * @param array $locale default country selections
     * @since 1.0
     * @return array $locale modified countrty selections
     */
    public function wdce_get_country_locale( $locale ) {
        $countries = array_merge( WC()->countries->get_allowed_countries(), WC()->countries->get_shipping_countries() );
        $countries = array_keys( $countries );

        if( is_array( $locale ) && is_array( $countries ) ) {
            foreach( $countries as $country ) {
                if( isset( $locale[$country] ) ) {
                    $locale[$country] = $this->wdce_prepare_country_locale( $locale[$country] );
                }
            }
        }
        return $locale;
    }

    /**
     * Modify billing fields - $fields is passed via the filter!
     * 
     * @param array $fields default billing fields
     * @since 1.0
     * @return array $fields modified billing fields
     */
    public function wdce_woocommerce_billing_fields( $fields ) {
        return $this->wdce_prepare_address_fields( get_option('wc_fields_billing'), $fields ); 
    }

    /**
     * Modify shipping fields - $fields is passed via the filter!
     * 
     * @param array $fields default shipping fields
     * @since 1.0
     * @return array $fields modified shipping fields
     */
    public function wdce_woocommerce_shipping_fields( $fields ) {
        return $this->wdce_prepare_address_fields( get_option('wc_fields_shipping'), $fields );
    }

    /**
     * Prepare default fields for modification
     * 
     * @param array $fieldset modified fields
     * @param array $original_fieldset default fields
     * @since 1.0
     * @return $fields
     */
    public function wdce_prepare_address_fields( $fieldset, $original_fieldset = false ){
        if ( is_array( $fieldset ) && ! empty( $fieldset ) ) {
            $fieldset = $this->wdce_prepare_checkout_fields( $fieldset, $original_fieldset );
            return $fieldset;
        }else {
            return $original_fieldset;
        }
    }

    /**
     * Prepare default checkout fields for modification
     * 
     * @param array $fields modified fields
     * @param array $original_fields default fields
     * @since 1.0
     * @return $fields
     */
    public function wdce_prepare_checkout_fields( $fields, $original_fields ) {
        if( is_array( $fields ) && ! empty( $fields ) ) {    
            $new_fields = array();       
            foreach( $fields as $name => $field ) {            
                if( Woocommerce_Default_Checkout_Editor::wdce_is_enabled( $field ) ) {
                    $new_field = false;
                    
                    if($original_fields && isset($original_fields[$name])){
                        $new_field = $original_fields[$name];

                        $class     = isset($field['class']) && is_array($field['class']) ? $field['class'] : array();
                        $required  = isset($field['required']) ? $field['required'] : 0;

                        $new_field['required'] = $required;

                        if( $required ) {
                            $class[] = 'wdce-required';
                        }else{
                            $class[] = 'wdce-optional';
                        }
                        
                        $new_field['label']       = isset($field['label']) ? $field['label'] : '';
                        $new_field['default']     = isset($field['default']) ? $field['default'] : '';
                        $new_field['placeholder'] = isset($field['placeholder']) ? $field['placeholder'] : '';
                        $new_field['class']       = $class;
                        $new_field['label_class'] = isset($field['label_class']) && is_array($field['label_class']) ? $field['label_class'] : array();
                        $new_field['validate']    = isset($field['validate']) && is_array($field['validate']) ? $field['validate'] : array();
                        $new_field['priority']    = isset($field['priority']) ? $field['priority'] : '';
                    } else {
                        $new_field = $field;
                    }

                    $type = isset($new_field['type']) ? $new_field['type'] : 'text';

                    $new_field['class'][] = 'wdce-field-wrapper';
                    $new_field['class'][] = 'wdce-field-'.$type;
                    
                    if($type === 'select' || $type === 'radio'){
                        if(isset($new_field['options'])){
                            $options_arr = Woocommerce_Default_Checkout_Editor::wdce_prepare_field_options($new_field['options']);
                            $options = array();
                            foreach($options_arr as $key => $value) {
                                $options[$key]    = __($value, 'woocommerce_default_checkout_editor');
                            }
                            $new_field['options'] = $options;
                        }
                    }

                    if(($type === 'select' || $type === 'multiselect')){
                        $new_field['input_class'][] = 'wdce-enhanced-select';
                    }
                    
                    if(isset($new_field['label'])){
                        $new_field['label'] = __($new_field['label'], 'woocommerce_default_checkout_editor');
                    }

                    if(isset($new_field['placeholder'])){
                        $new_field['placeholder'] = __($new_field['placeholder'], 'woocommerce_default_checkout_editor');
                    }
                    
                    $fields[$name] = $new_field;
                }else{
                    unset($fields[$name]);
                }
            }
            return $fields;
        }else {
            return $original_fields;
        }
    }

    /**
     * Enqueue Scripts and Styles fro checkout page only
     * 
     * @since 1.0
     */
    public function wdce_enqueue_styles_and_scripts() {
        if( is_checkout() ){
            $in_footer  = apply_filters( 'wdce_enqueue_script_in_footer', true );
            wp_register_script( 'wdce-checkout-script', WDCE_PLUGIN_URL . '/assets/js/wdce_front.js', array(), WDCE_VERSION, $in_footer );
            wp_enqueue_script('wdce-checkout-script');
        }
    }
}

if ( class_exists( 'Woocommerce_Default_Checkout_Editor_General_Fornt_Setting', false ) ) {
    return new Woocommerce_Default_Checkout_Editor_General_Fornt_Setting();
}
?>