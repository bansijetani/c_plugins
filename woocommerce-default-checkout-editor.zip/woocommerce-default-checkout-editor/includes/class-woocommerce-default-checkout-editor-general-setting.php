<?php

/**
 * Set Woocommerce Default Checkout Editor
 * 
 * @package Woo_Dce
 *
 * @since 1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Woocommerce_Default_Checkout_Editor_General_Setting Class.
 * @since 1.0
 */

class Woocommerce_Default_Checkout_Editor_General_Setting {

    protected $sections = '';

    /**
     * Constructer Function
     *
     * @since 1.0
     * @return void
     */
    public function __construct(){
        $this->sections = array(
            'billing' => __( 'Billing Fields', 'woocommerce_default_checkout_editor' ),
            'shipping' => __( 'Shipping Fields', 'woocommerce_default_checkout_editor' ),
        );

        $this->wdce_init_hooks();
    }

    /**
     * Include required action/filter here
     * 
     * @since 1.0
     * @return void
     */
    public function wdce_init_hooks() {
 
    }

    /**
     * Use for show error message notice.
     * 
     * @param string $msg message to be written
     * @param string $type='updated' 
     * @param boolean $return=false
     * @since 1.0
     * @return string $notice
     */
    public function wdce_print_notices( $msg, $type='updated', $return=false ) {
        $notice = '<div class="wdce-notice '. $type .'"><p>'. $msg .'</p></div>';
        if( ! $return ){
            echo $notice;
        }
        return $notice;
    }

    /**
     * Update default checkout field's data
     * 
     * @param string $key what type of fields
     * @since 1.0
     * @return array $fields chekcout form fields
     */
    public function wdce_get_fields( $key ) {
        $fields = get_option( 'wc_fields_'. $key, array() );
        $fields = is_array( $fields ) ? array_filter( $fields ) : array();
        
        if( empty( $fields ) || sizeof( $fields ) == 0 ) {
            if($key === 'billing' || $key === 'shipping'){
                $fields = WC()->countries->get_address_fields(WC()->countries->get_base_country(), $key . '_');
            } 
        }
        $fields = $this->wdce_prepare_default_fields( $fields );
        return $fields;
    }

    /**
     * Set 'enabled=false' if fields is active
     * 
     * @param array $fields default chekcout form fields
     * @since 1.0
     * @return array $fields modified chekcout form fields
     */
    public function wdce_prepare_default_fields( $fields ){
        foreach ( $fields as $key => $value ) {
            if( isset( $value['enabled'] ) ){
                $fields[$key]['enabled'] = $value['enabled'];
            }else{
                $fields[$key]['enabled'] = 1;
            }            
        }
        return $fields;
    }

    /**
     * Update checkout fields data
     * 
     * @param string $key what type of fields
     * @param array $fields checkout fieds
     * @since 1.0
     * @return $result
     */
    public function wdce_update_fields( $key, $fields ){
        $result = update_option( 'wc_fields_' . $key, $fields, 'no' );
        return $result;
    }

    /**
     * Get current section from URL
     * 
     * @since 1.0
     * @return string $section current section
     */
    public function wdce_get_current_section() {
        $section = isset( $_GET['section'] ) ? sanitize_key( $_GET['section'] ) : 'billing';
        return $section;
    }

    /**
     * Woocommerce Default Checkout Editor type urls.
     * 
     * @since 1.0
     * @return void
     */
    public function wdce_checkout_types_urls() {
        $result          = false;
        $current_section = $this->wdce_get_current_section();

        if( empty( $this->sections ) ) {
            return;
        }
        
        $array_keys = array_keys( $this->sections );
        
        echo '<ul class="wdce-sections">';
        foreach( $this->sections as $id => $label ) {
            $url = $this->wdce_get_admin_url( sanitize_title( $id ) ); 
            echo '<li><a href="'.esc_url($url) .'" class="'. ( $current_section == $id ? 'current' : '' ) .'">'. $label .'</a> '. (end( $array_keys ) == $id ? '' : '|') .' </li>';
        }       
        echo '</ul>';

        if( $result ){
            echo $result;
        }
    }

    /**
     * Get admin URL from section
     * 
     * @param string $section current section name
     * @since 1.0
     * @return string admin url
     */
    public function wdce_get_admin_url( $section = false ) {
        $url = 'admin.php?page=woocommerce_default_checkout_editor_forms';

        if( $section && ! empty( $section ) ){
            $url .= '&section='. $section;
        }
        return admin_url( $url );
    }

    /**
     * Woocommerce default checkout editor heading fields row.
     * 
     * @since 1.0
     * @return void
     */
    public function wdce_render_checkout_fields_heading_row(){
        ?>
        <th class="sort"></th>
        <th class="check-column"><input type="checkbox" style="margin:0px;" onclick="wdceSelectAllCheckoutFields(this)"></th>
        <th class="name"><?php _e('Name', 'woocommerce_default_checkout_editor'); ?></th>
        <th class="id"><?php _e('Type', 'woocommerce_default_checkout_editor'); ?></th>
        <th><?php _e('Label', 'woocommerce_default_checkout_editor'); ?></th>
        <th><?php _e('Placeholder', 'woocommerce_default_checkout_editor'); ?></th>
        <th class="status"><?php _e('Required', 'woocommerce_default_checkout_editor'); ?></th>   
        <?php
    }
    

    /**
     * Woocommerce default checkout editor action button.
     * 
     * @since 1.0
     * @return void
     */
    public function wdce_render_actions_row(){
    ?>
        <th colspan="10">
            <input type="submit" name="save_fields" class="button-primary" value="<?php _e( 'Save changes', 'woocommerce_default_checkout_editor' ) ?>" style="float:right" />
            <input type="submit" name="reset_fields" class="button" value="<?php _e( 'Reset to default fields', 'woocommerce_default_checkout_editor' ) ?>" style="float:right; margin-right: 5px;" 
            onclick="return confirm('<?php _e('Are you sure you want to reset to default fields? all your changes will be deleted.', 'woocommerce_default_checkout_editor' ); ?>')"/>
        </th>  
    <?php 
    }

    /**
     * Woocommerce default checkout editor table.
     * 
     * @since 1.0
     * @return void
     */
    public function wdce_woocommerce_listing_billing_fields() {

        $section = 'billing';
        if ( isset ( $_GET['section'] ) ) {
            $section = $_GET['section'];
        }

        if ( isset( $_POST['save_fields'] ) ) {
            echo $this->wdce_save_fields($section);
        }       

        if ( isset( $_POST['reset_fields'] ) ) {
            echo $this->reset_to_default();
        }

        $fields = $this->wdce_get_fields($section);
    ?>            
        <div class="wrap woocommerce">
            <div class="icon32 icon32-attributes" id="icon-woocommerce"><br />
            </div>
            <form method="post" id="wdce_checkout_fields_form" action="">
                <table id="wdce_checkout_fields" class="wc_gateways widefat thpladmin_fields_table" cellspacing="0">
                    <thead>
                        <tr><?php $this->wdce_render_actions_row(); ?></tr>
                        <tr><?php $this->wdce_render_checkout_fields_heading_row(); ?></tr>                      
                    </thead>
                    <tfoot>
                        <tr><?php $this->wdce_render_checkout_fields_heading_row(); ?></tr>
                        <tr><?php $this->wdce_render_actions_row(); ?></tr>
                    </tfoot>
                    <tbody class="ui-sortable">
                        <?php 
                        $i=0;
                        foreach( $fields as $name => $field ) :
                            $type        = isset( $field['type'] ) ? $field['type'] : '';
                            $label       = isset( $field['label'] ) ? $field['label'] : '';
                            $placeholder = isset( $field['placeholder'] ) ? $field['placeholder'] : '';
                            $validate    = isset( $field['validate'] ) ? $field['validate'] : '';
                            $required    = isset( $field['required'] ) && $field['required'] ? 1 : 0;
                            $enabled     = isset( $field['enabled'] ) && $field['enabled'] ? 1 : 0;
                            $custom      = isset( $field['custom'] ) && $field['custom'] ? 1 : 0;

                            $required_status = $required ? 'checked' : '';
                            $enabled_status  = $enabled ? 'checked=true' : '';

                            $props_json   = htmlspecialchars($this->wdce_get_property_set_json($name, $field));
                            $options_json = isset( $field['options_json'] ) && $field['options_json'] ? htmlspecialchars( $field['options_json'] ) : '';

                            $options_json = '';
                            if($type === 'select' || $type === 'radio' || $type === 'checkboxgroup' || $type === 'multiselect'){
                                $options      = isset( $field['options'] ) ? $field['options'] : '';
                                $options_json = $this->wdce_prepare_options_json( $options );
                            }
                        ?>
                        <tr class="row_<?php echo $i; echo $enabled ? '' : ' thpladmin-disabled' ?>">
                            <td width="1%" class="sort ui-sortable-handle">
                                <input type="hidden" name="f_name[<?php echo $i; ?>]" class="f_name" value="<?php echo esc_attr($name); ?>" />
                                <input type="hidden" name="f_name_new[<?php echo $i; ?>]" class="f_name_new" value="" />
                                <input type="hidden" name="f_order[<?php echo $i; ?>]" class="f_order" value="<?php echo $i; ?>" />
                                <input type="hidden" name="f_deleted[<?php echo $i; ?>]" class="f_deleted" value="0" />
                                <input type="hidden" name="f_enabled[<?php echo $i; ?>]" class="f_enabled" value="<?php echo $enabled; ?>" />
                                <input type="hidden" name="f_props[<?php echo $i; ?>]" class="f_props_<?php echo $i; ?>" value='<?php echo $props_json; ?>' />
                                <input type="hidden" name="f_options[<?php echo $i; ?>]" class="f_options" value='<?php echo $options_json; ?>' />
                            </td>
                            <td class="td_enabled status <?php echo ( ! $enabled ) ? 'td_select' : ''; ?>"><input type="checkbox" value="1" name="wdce_enabled_<?php echo $i; ?>" class="wdce_checkbox" <?php echo $enabled_status; ?> /></td>
                            <!-- <td class="td_select"><input type="checkbox" class="" name="select_field" onclick="wdceEnableSelectedFields(this)" /></td> -->
                            <td class="td_name"><?php echo esc_attr( $name ); ?></td>
                            <td class="td_type"><?php echo esc_attr( $type ); ?></td>

                            <td class="td_label"><input type="text" id="wdce_label" name="wdce_label_<?php echo $i; ?>" class="wdce_input_field" value="<?php echo esc_html_e($label, 'woocommerce_default_checkout_editor'); ?>"></td>

                            <td class="td_placeholder"><input type="text" id="wdce_placeholder" name="wdce_placeholder_<?php echo $i; ?>" class="wdce_input_field" value="<?php echo esc_html_e($placeholder, 'woocommerce_default_checkout_editor'); ?>"></td>

                            <td class="td_required status"><input type="checkbox" value="1" id="wdce_frequired" name="wdce_required_<?php echo $i; ?>" class="wdce_checkbox" <?php echo $required_status;?>/></td>

                    
                        </tr>
                        <?php 
                            $i++; 
                            endforeach; 
                        ?>
                    </tbody>
                </table>
            </form>
        </div>
        <?php
    }

    /**
     * Woocommerce default checkout save fields.
     * 
     * @param string $section current section name
     * @since 1.0
     * @return void
     */
    public function wdce_save_fields( $section ) {            
        $f_names = ! empty( $_POST['f_name'] ) ? $_POST['f_name'] : array();
        $f_names = array_map( 'sanitize_key', $f_names );
        if( empty( $f_names ) ) {
            $this->wdce_print_notices( __( 'Your changes were not saved due to no fields found.', 'woocommerce_default_checkout_editor' ), 'error' );
            return;
        }
        
        $f_order   = ! empty( $_POST['f_order'] ) ? $_POST['f_order'] : array();
        $f_order   = array_map( 'absint', $f_order );
        $f_deleted = ! empty( $_POST['f_deleted'] ) ? $_POST['f_deleted'] : array();
        $f_deleted = array_map( 'absint', $f_deleted );
        $f_enabled = ! empty( $_POST['f_enabled'] ) ? $_POST['f_enabled'] : array();
        $f_enabled = array_map( 'absint', $f_enabled );
          
        $fields = $this->wdce_get_fields( $section );
        $max = max( array_map( 'absint', array_keys( $f_names ) ) );
        for( $i = 0; $i <= $max; $i++ ) {
            $name = $f_names[$i];
            
            if( isset( $fields[$name] ) ) {
                $is_deleted = isset( $f_deleted[$i] ) && $f_deleted[$i] ? true : false;

                if( $is_deleted ){
                    unset( $fields[$name] );
                    continue;
                }
                $order      = isset( $f_order[$i] ) ? $f_order[$i] : 0;
                $enabled    = isset( $_POST['wdce_enabled_'.$i] ) ? $_POST['wdce_enabled_'.$i] : 0;
                $required   = isset( $_POST['wdce_required_'.$i] ) ? (int) $_POST['wdce_required_'.$i] : 0;
                
                $field                = $fields[$name];
                $field['enabled']     = $enabled;
                $field['label']       = $_POST['wdce_label_'.$i];
                $field['placeholder'] = $_POST['wdce_placeholder_'.$i];
                $field['required']    = $required;          
                
                $fields[$name]        = $field;
            }
        }
        $fields = Woocommerce_Default_Checkout_Editor::wdce_sort_fields( $fields );
        $result = $this->wdce_update_fields( $section, $fields );
        
        if( $result == true ) {
            $this->wdce_print_notices(__('Your changes were saved.', 'woocommerce_default_checkout_editor'), 'updated');
        }else {
            $this->wdce_print_notices(__('Your changes were not saved due to an error (or you made none!).', 'woocommerce_default_checkout_editor'), 'error');
        }
    }

    /**
     * Woocommerce default checkout set field json.
     * 
     * @param string $name checkout field name
     * @param array $field checkout field
     * @since 1.0
     * @return string $json encoded json fields
     */
    public function wdce_get_property_set_json( $name, $field ) {
        $json = '';
        if( is_array( $field ) ) {
            foreach( $field as $pname => $pvalue ) {
                $pvalue = is_array( $pvalue ) ? implode( ',', $pvalue ) : $pvalue;
                $pvalue = is_string( $pvalue ) ? esc_attr( $pvalue ) : $pvalue;
                
                $field[$pname] = $pvalue;
            }

            $field['name'] = $name;
            $json          = json_encode($field);
        }
        return $json;
    }

    /**
     * Woocommerce default checkout set field json.
     * 
     * @param array $options 
     * @since 1.0
     * @return $options_json
     */
    public function wdce_prepare_options_json( $options ) {
        $options_json = '';
        if( is_array( $options ) && ! empty ( $options ) ) {
            $options_arr = array();

            foreach ( $options as $okey => $otext ) {
                array_push( $options_arr, array( "key" => $okey, "text" => $otext ) );
            }

            $options_json = json_encode( $options_arr );
            $options_json = rawurlencode( $options_json );
        }
        return $options_json;
    }

    /**
     * set for reset all fields.
     * 
     * @since 1.0
     * @return void
     */
    public function reset_to_default() {
        $section = $_GET['section'];
        $msg     = '';
        if( $section == 'billing' ){
            delete_option('wc_fields_billing');
            $msg = 'Billing fields successfully reset';
        }
        if( $section == 'shipping' ){
            delete_option('wc_fields_shipping');
            $msg = 'Shipping fields successfully reset';
        }
        return $this->wdce_print_notices( __( $msg, 'woocommerce_default_checkout_editor' ), 'updated', true );
    }
}

if ( class_exists( 'Woocommerce_Default_Checkout_Editor_General_Setting', false ) ) {
    return new Woocommerce_Default_Checkout_Editor_General_Setting();
}

?>