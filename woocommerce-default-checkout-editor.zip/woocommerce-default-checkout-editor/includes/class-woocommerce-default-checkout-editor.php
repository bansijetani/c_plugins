<?php
/**
 * Set Woocommerce Default Checkout Editor
 *
 * @package Woo_Dce
 *
 * @since 1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Main Plugin Class.
 *
 * @class Woocommerce_Default_Checkout_Editor
 */
class Woocommerce_Default_Checkout_Editor {

    /**
     * The single instance of the class.
     *
     * @var class object
     * @since 1.0
     */
    protected static $instance = null;


    /**
     * Main Woocommerce_Default_Checkout_Editor Instance.
     *
     * Ensures only one instance of WpContentLocker is loaded or can be loaded.
     *
     * @since 1.0
     * @return Woocommerce_Default_Checkout_Editor - Main instance.
     */
    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Woocommerce Default Checkout Editor Change for WooCommerce Constructor.
     *
     * @since 1.0
     * @return void
     */
    public function __construct() {
        $this->wdce_includes();
    }

    /**
     * Include required files
     *
     * @since 1.0
     * @return void
     */
    public function wdce_includes() {

        include_once dirname( WDCE_PLUGIN_DIR ) . '/includes/class-woocommerce-default-checkout-editor-general-setting.php';  
        include_once dirname( WDCE_PLUGIN_DIR ) . '/includes/class-woocommerce-default-checkout-editor-admin.php';
        include_once dirname( WDCE_PLUGIN_DIR ) . '/includes/class-woocommerce-default-checkout-editor-general-fornt-setting.php';
    }

    /**
     * Sort checkout fields fields
     *
     * @param array $fields checkout fields
     * @since 1.0
     * @return array $fields checkout fields
     */
    public static function wdce_sort_fields( $fields ){
        uasort($fields, 'wc_checkout_fields_uasort_comparison');
        return $fields;
    }

    /**
     * Check if field is enable or not
     *
     * @param array $field checkout field
     * @since 1.0
     * @return boolean $enabled true / false
     */
    public static function wdce_is_enabled( $field ){
        $enabled = false;
        if( is_array ( $field ) ) {
            $enabled = isset( $field['enabled']) && $field['enabled'] == false ? false : true;
        }
        return $enabled;
    }

    /**
     * Senitize checkout field's options
     *
     * @param array $options checkout field's options
     * @since 1.0
     * @return array $options senitized checkout field's options
     */
    public static function wdce_prepare_field_options( $options ){
        if(is_string($options)){
            $options = array_map('trim', explode('|', $options));
        }
        return is_array($options) ? $options : array();
    }
}

if ( class_exists( 'Woocommerce_Default_Checkout_Editor', false ) ) {
    return new Woocommerce_Default_Checkout_Editor();
}
