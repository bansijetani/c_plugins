
var wdce_settings = (function($, window, document) {

	function select_all_fields(elm){
		var checkAll = $(elm).prop('checked');
		$('#wdce_checkout_fields tbody td.td_enabled input[type=checkbox]').prop('checked', checkAll);
	}

	function enable_disable_selected_fields(enabled){
		$('#wdce_checkout_fields tbody input[type=checkbox][name=select_field]:checked').each(function(){
			var row = $(this).closest('tr');
			if(enabled == 0){
				if(!row.hasClass("thpladmin-disabled")){
					row.addClass("thpladmin-disabled");
				}
			}else{
				row.removeClass("thpladmin-disabled");				
			}
			row.find(".td_enabled").html(enabled == 1 ? '<span class="dashicons dashicons-yes tips" data-tip="Yes"></span>' : '-');
			row.find(".f_enabled").val(enabled);
	  	});	
	}



	return {
		selectAllFields             : select_all_fields,
		enableDisableSelectedFields : enable_disable_selected_fields,
   	};
}(window.jQuery, window, document));

function wdceSelectAllCheckoutFields(elm){
	wdce_settings.selectAllFields(elm);
}

function wdceEnableSelectedFields(ele){
console.log( jQuery(this).is(':checked') );
	wdce_settings.enableDisableSelectedFields(1);
}

function wdceDisableSelectedFields(){
	wdce_settings.enableDisableSelectedFields(0);
}